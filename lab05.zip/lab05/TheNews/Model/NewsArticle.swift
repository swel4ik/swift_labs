//
//  NewsArticle.swift
//  TheNews
//
//  Created by Nikita on 18/04/21

import Foundation

struct NewsArticle: Decodable {
    var title: String?
    var url: String?
    var urlToImage: String?
    var content: String?
}

struct NewsArticleList: Decodable {
   var articles: [NewsArticle]
}
