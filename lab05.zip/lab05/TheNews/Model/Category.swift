//
//  Category.swift
//  TheNews
//
//  Created by Nikita on 18/04/21

import Foundation

struct Category {
    var categoryName: String
}
