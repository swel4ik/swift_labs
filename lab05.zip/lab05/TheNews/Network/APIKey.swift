//
//  APIKey.swift
//  TheNews
//
//  Created by Nikita on 18/04/21

import Foundation

public let apiKey = "f449eab127f242f9a6c175bd4c7021a1"
