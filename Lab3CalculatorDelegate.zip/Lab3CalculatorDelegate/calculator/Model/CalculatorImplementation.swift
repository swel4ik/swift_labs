//
//  CalculatorImplementation.swift
//  calculator
//
//  Created by MacBook Pro on 23.02.2021.
//  Copyright © 2021 Илья Лошкарёв. All rights reserved.
//

import Foundation

class CalculatorImpl: Calculator {
    
    var _inputLength: UInt
    var _maxFraction: UInt

    var _delegate: CalculatorDelegate?
    
    var delegate: CalculatorDelegate? {
        get {
            return self._delegate
        }
        set(newDelegate) {
            self._delegate = newDelegate
        }
    }
    
    required init(inputLength len: UInt, maxFraction frac: UInt) {
        _inputLength = len
        _maxFraction = frac
        _hasPoint = false
        digitsBeforePoint = []
        digitsAfterPoint = []
    }
    
    var _result:Double?
    var result: Double? {
        get {
            return _result
        }
    }
    
    var _operation: Operation?
    var operation: Operation? {
        get {
            return _operation
        }
    }
    
    var input: Double? {
        get {
            let before = digitsBeforePoint.joined(separator: "")
            let after = digitsAfterPoint.joined(separator: "")
            return Double(before + "." + after)
        }
        
        set (newInput) {
            if (newInput != nil) {
                let arr = String(newInput!).components(separatedBy: ".")
                digitsBeforePoint = arr[0].map { String($0) }
                if (countNumsAfterPoint(d: newInput) > 0 && arr.count > 1) {
                    digitsAfterPoint = arr[1].map { String($0) }
                    while digitsAfterPoint.last == "0" {
                        digitsAfterPoint.popLast()
                    }
                    addPoint()
                }
                print(digitsAfterPoint, digitsBeforePoint, "SEP")
            }
        }
    }
    
    var digitsBeforePoint: Array<String>
    var digitsAfterPoint: Array<String>
    
    func addDigit(_ d: Int) {
        if (digitsAfterPoint.count >= _maxFraction || (digitsBeforePoint.count + digitsAfterPoint.count) >= _inputLength) {
            delegate?.calculatorDidInputOverflow(self)
            return
        }
        if (hasPoint) {
            digitsAfterPoint.append(String(d))
        } else {
            digitsBeforePoint.append(String(d))
        }
        if (input != nil) {
            delegate?.calculatorDidUpdateValue(self, with: input!, valuePrecision: fractionDigits)
        }
    }
    
    func addPoint() {
        _hasPoint = true
        delegate?.calculatorDidUpdateValue(self, with: input!, valuePrecision: fractionDigits)
    }
    
    var _hasPoint:Bool
    var hasPoint: Bool {
        get {
            return _hasPoint
        }
    }
    
    var fractionDigits: UInt {
        get {
            return UInt(digitsAfterPoint.count)
        }
    }
    
    func addOperation(_ op: Operation) {
        if (hasPoint && digitsAfterPoint.count < 1) {
            delegate?.calculatorDidNotCompute(self, withError: "Bad value, enter number after point")
            return
        }
        if (op == Operation.sign && _result != nil && input == nil) {
            _result = -_result!
            delegate?.calculatorDidUpdateValue(self, with: result ?? 0, valuePrecision: countNumsAfterPoint(d: result))
            return
        } else if (op == Operation.perc && _result != nil && input == nil) {
            if (countNumsAfterPoint(d: _result) >= _maxFraction) {
                delegate?.calculatorDidInputOverflow(self)
                return
            }
            _result = Double((_result!/100).removeZerosFromEnd())
            delegate?.calculatorDidUpdateValue(self, with: result ?? 0, valuePrecision: countNumsAfterPoint(d: result))
            return
        } else if (op == Operation.sign && _result == nil && input != nil) {
            input = -input!
            delegate?.calculatorDidUpdateValue(self, with: input ?? 0, valuePrecision: countNumsAfterPoint(d: input))
            return
        } else if (op == Operation.perc && _result == nil && input != nil) {
            if (countNumsAfterPoint(d: input) >= _maxFraction) {
                delegate?.calculatorDidInputOverflow(self)
                return
            }
            
            input = Double((input!/100).removeZerosFromEnd())
            delegate?.calculatorDidUpdateValue(self, with: input ?? 0, valuePrecision: countNumsAfterPoint(d: input))
            return
        }
        
        if (_operation != nil) {
            compute()
        } else if (_result == nil) {
            _result = input
            digitsBeforePoint = []
            digitsAfterPoint = []
            _hasPoint = false
        }
        _operation = op
    }
    
    func compute() {
        if (_result == nil || input == nil) {
            return
        }
        switch operation {
        case .add:
            _result! += input!
        case .sub:
            _result! -= input!
        case .mul:
            _result! *= input!
        case .div:
            if (input == 0) {
                reset()
                clear()
                delegate?.calculatorDidNotCompute(self, withError: "Not definitely")
                return
            }
            _result! /= input!
        case .sign:
            print("none")
        case .perc:
            print("none")
        default:
            print("none")
        }
        
        digitsBeforePoint = []
        digitsAfterPoint = []
        _hasPoint = false
        delegate?.calculatorDidUpdateValue(self, with: result ?? 0, valuePrecision: countNumsAfterPoint(d: result))
    }
    
    func clear() {
        digitsBeforePoint = []
        digitsAfterPoint = []
        _hasPoint = false
        delegate?.calculatorDidClear(self, withDefaultValue: 0, defaultPrecision: 0)
    }
    
    func reset() {
        end()
        delegate?.calculatorDidClear(self, withDefaultValue: 0, defaultPrecision: 0)
    }
    
    func end() {
        input = _result
        _result = nil
        _operation = nil
    }
    
    func countNumsAfterPoint(d: Double?) -> UInt {
        if (d == nil) {
            return 0
        }
        return min(UInt(max(-Decimal(d!).exponent, 0)), _maxFraction)
    }
}

extension Double {
    func removeZerosFromEnd() -> String {
        let formatter = NumberFormatter()
        let number = NSNumber(value: self)
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = 16 //maximum digits in Double after dot (maximum precision)
        return String(formatter.string(from: number) ?? "")
    }
}
