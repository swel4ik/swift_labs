//
//  Calculator.swift
//  calculator
//
//  Created by Илья Лошкарёв on 21.09.17.
//  Copyright © 2017 Илья Лошкарёв. All rights reserved.
//

import Foundation


/// Доступные операции
public enum Operation: String {
    case add = "+",
    sub = "-",
    mul = "×",
    div = "÷",
    sign = "±",
    perc = "%"
}


/// Протокол калькулятора
public protocol Calculator: class { // можно реализовывать только в ссылочном типе
    
    /// Представитель – объект, реагирующий на изменение внутреннего состояния калькулятора
    var delegate: CalculatorDelegate? { get set }
    
    /// Инициализатор
    /// `inputLength` – максимальная длина поля ввода (количество символов)
    /// `fractionLength` – максимальное количество знаков после заятой
    init(inputLength len: UInt, maxFraction frac: UInt)
    
    // Хранимое выражение: <левое значение> <операция> <правое значение>
    
    /// Левое значение - обычно хранит результат предыдущей операции
    var result: Double? { get }
    
    /// Текущая операция
    var operation: Operation? { get }
    
    /// Правое значение - к нему пользователь добавляет цифры
    var input: Double? { get }
    
    /// Добавить цифру к правому значению
    func addDigit(_ d: Int)
    
    /// Добавить точку к правому значению
    func addPoint()
    
    /// Правое значение содержит точку
    var hasPoint: Bool { get }
    
    /// Количество текущих знаков после запятой в правом значении
    var fractionDigits: UInt { get }
    
    /// Добавить операцию, если операция уже задана,
    /// вычислить предыдущее значение
    func addOperation(_ op: Operation)
    
    /// Вычислить значение выражения и записать его в левое значение
    func compute()
    
    /// Очистить правое значение
    func clear()
    
    /// Очистить всё выражение
    func reset()
    
    func afterCompute()
}

class CalculatorImpl: Calculator {
    
    var _inputLength: UInt
    var _maxFraction: UInt

    var _delegate: CalculatorDelegate?
    
    var delegate: CalculatorDelegate? {
        get {
            return self._delegate
        }
        set(newDelegate) {
            self._delegate = newDelegate
        }
    }
    
    required init(inputLength len: UInt, maxFraction frac: UInt) {
        _inputLength = len
        _maxFraction = frac
        _hasPoint = false
        digitsBeforePoint = []
        digitsAfterPoint = []
    }
    
    var _result:Double?
    var result: Double? {
        get {
            return _result
        }
    }
    
    var _operation: Operation?
    var operation: Operation? {
        get {
            return _operation
        }
    }
    
    var input: Double? {
        get {
            let before = digitsBeforePoint.joined(separator: "")
            let after = digitsAfterPoint.joined(separator: "")
            return Double(before + "." + after)
        }
        
        set (newInput) {
            if (newInput != nil) {
                let elements = String(newInput!).components(separatedBy: ".")
                digitsBeforePoint = elements[0].map { val in return String(val) }
                if (countNumsAfterPoint(d: newInput) > 0 && elements.count > 1) {
                    digitsAfterPoint = elements[1].map { val in return String(val) }
                    while digitsAfterPoint.last == "0" {
                        digitsAfterPoint.popLast()
                    }
                    addPoint()
                }
            }
        }
    }
    
    var digitsBeforePoint: Array<String>
    var digitsAfterPoint: Array<String>
    
    func addDigit(_ d: Int) {
        if (digitsAfterPoint.count >= _maxFraction || (digitsBeforePoint.count + digitsAfterPoint.count) >= _inputLength) {
            delegate?.calculatorDidInputOverflow(self)
            return
        }
        if (hasPoint) {
            digitsAfterPoint.append(String(d))
        } else {
            digitsBeforePoint.append(String(d))
        }
        if (input != nil) {
            delegate?.calculatorDidUpdateValue(self, with: input!, valuePrecision: fractionDigits)
        }
    }
    
    func addPoint() {
        _hasPoint = true
        delegate?.calculatorDidUpdateValue(self, with: input!, valuePrecision: fractionDigits)
    }
    
    var _hasPoint: Bool
    var hasPoint: Bool {
        get {
            return _hasPoint
        }
    }
    
    var fractionDigits: UInt {
        get {
            return UInt(digitsAfterPoint.count)
        }
    }
    
    func addOperation(_ op: Operation) {
        if (op == Operation.sign && _result != nil && input == nil) {
            _result = -_result!
            delegate?.calculatorDidUpdateValue(self, with: result ?? 0, valuePrecision: countNumsAfterPoint(d: result))
            return
        } else if (op == Operation.perc && _result != nil && input == nil) {
            if (countNumsAfterPoint(d: _result) >= _maxFraction) {
                delegate?.calculatorDidInputOverflow(self)
                return
            }
            _result = Double((_result!/100))
            delegate?.calculatorDidUpdateValue(self, with: result ?? 0, valuePrecision: countNumsAfterPoint(d: result))
            return
        } else if (op == Operation.sign && _result == nil && input != nil) {
            input = -input!
            delegate?.calculatorDidUpdateValue(self, with: input ?? 0, valuePrecision: countNumsAfterPoint(d: input))
            return
        } else if (op == Operation.perc && _result == nil && input != nil) {
            if (countNumsAfterPoint(d: input) >= _maxFraction) {
                delegate?.calculatorDidInputOverflow(self)
                return
            }
            input = Double((input!/100))
            delegate?.calculatorDidUpdateValue(self, with: input ?? 0, valuePrecision: countNumsAfterPoint(d: input))
            return
        }
        
        if (_operation != nil) {
            compute()
        } else if (_result == nil) {
            _result = input
            digitsBeforePoint = []
            digitsAfterPoint = []
            _hasPoint = false
        }
        _operation = op
    }
    
    func compute() {
        if (_result == nil || input == nil) {
            return
        }
        switch operation {
        case .add:
            _result! += input!
        case .sub:
            _result! -= input!
        case .mul:
            _result! *= input!
        case .div:
            if (input == 0) {
                reset()
                clear()
                delegate?.calculatorDidNotCompute(self, withError: "Not definitely")
                return
            }
            _result! /= input!
        case .sign:
            print("none")
        case .perc:
            print("none")
        default:
            print("none")
        }
        
        digitsBeforePoint = []
        digitsAfterPoint = []
        _hasPoint = false
        delegate?.calculatorDidUpdateValue(self, with: result ?? 0, valuePrecision: countNumsAfterPoint(d: result))
    }
    
    func clear() {
        digitsBeforePoint = []
        digitsAfterPoint = []
        _hasPoint = false
        delegate?.calculatorDidClear(self, withDefaultValue: 0, defaultPrecision: 0)
    }
    
    func reset() {
        afterCompute()
        delegate?.calculatorDidClear(self, withDefaultValue: 0, defaultPrecision: 0)
    }
    
    func afterCompute() {
        input = _result
        _result = nil
        _operation = nil
    }
    
    func countNumsAfterPoint(d: Double?) -> UInt {
        if (d == nil) {
            return 0
        }
        return min(UInt(max(-Decimal(d!).exponent, 0)), _maxFraction)
    }
}

